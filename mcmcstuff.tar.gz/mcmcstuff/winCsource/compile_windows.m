%
% Compile the C-source functions with Matlab. 
%
% Converts *.c functions to .mex* versions of desktop interface 
% in use.
%
% 


mex -O -output bbmean bbmean.c
mex -O -output bbprctile bbprctile.c
mex -O -output catrand catrand.c binsgeq.c
mex -O -output cond_invgam_invgam1 cond_invgam_invgam1.c ars.c rand.c
mex -O -output dirrand dirrand.c
mex -O -output exprand exprand.c
mex -O -output gamrand gamrand.c rand.c
mex -O -output gamrand1 gamrand1.c rand.c
mex -O -output gpexpcov gpexpcov.c 
mex -O -output gpexptrcov gpexptrcov.c 
mex -O -output invgamrand invgamrand.c rand.c
mex -O -output invgamrand1 invgamrand1.c rand.c
mex -O -output resampres resampres.c binsgeq.c
mex -O -output resampsim resampsim.c binsgeq.c
mex -O -output resampstr resampstr.c binsgeq.c
mex -O -output resampdet resampdet.c binsgeq.c
mex -O -output tanh_f tanh_f.c
mex -O -output trand trand.c rand.c

% The following routines use LAPACK libraries.

Compiler='Lcc';
% or Compiler='msvc';

% Use Lcc compiler, bundled with matlab
v = [1 0.1] * sscanf(version, '%d.%d');
if v < 6.5 
    error(['Automatic compilation is not coded. Check the location of';
           'lapack library and follow the lines below                '])
elseif v < 7.5
  mex -O -output gp2fwd gp2fwd.c libmwlapack.lib -f lccopts.bat
  mex -O -output gp2fwds gp2fwds.c libmwlapack.lib -f lccopts.bat
  mex -O -output gpexpedata gpexpedata.c libmwlapack.lib -f lccopts.bat
  mex -O -output gpexptrcovinv gpexptrcovinv.c libmwlapack.lib -f lccopts.bat
  mex -O -output gpvalues2 gpvalues.c libmwlapack.lib -f lccopts.bat
  mex -O -output mlp2bkp mlp2bkp.c libmwlapack.lib -f lccopts.bat
  mex -O -output mlp2fwd mlp2fwd.c libmwlapack.lib -f lccopts.bat
else
  mex -O -output gp2fwd gp2fwd.c libmwlapack.lib libmwblas.lib -f lccopts.bat
  mex -O -output gp2fwds gp2fwds.c libmwlapack.lib libmwblas.lib -f lccopts.bat
  mex -O -output gpexpedata gpexpedata.c libmwlapack.lib libmwblas.lib -f lccopts.bat
  mex -O -output gpexptrcovinv gpexptrcovinv.c libmwlapack.lib libmwblas.lib -f lccopts.bat
  mex -O -output gpvalues2 gpvalues.c libmwlapack.lib libmwblas.lib -f lccopts.bat
  mex -O -output mlp2bkp mlp2bkp.c libmwlapack.lib libmwblas.lib -f lccopts.bat
  mex -O -output mlp2fwd mlp2fwd.c libmwlapack.lib libmwblas.lib -f lccopts.bat
end

