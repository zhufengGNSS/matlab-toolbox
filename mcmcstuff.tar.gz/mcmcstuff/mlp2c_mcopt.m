function opt = mlp2c_mcopt(opt);
% MLP2C_MCOPT  Default options for MLP2R_MC
%
%   Description
%   OPT = MLP2C_MCOPT(OPT) takes an options structure OPT and
%   returns an options structure identical to the input except that
%   nonexisting fields in input are set to default.
%
%   Default options are:
%   nsamples = 1
%   repeat   = 1
%   display  = 1
%   plot     = 1
%   gibbs    = 0
%   hmc_opt  = hmc2_opt
%     hmc_opt.stepsf  = 'mlp2c_steps'
%   persistence_reset = 0
%   sample_inputs  = 0

% Copyright (c) 1999 Aki Vehtari

% This software is distributed under the GNU General Public 
% License (version 2 or later); please refer to the file 
% License.txt, included with the software, for details.

if nargin < 1
  opt=[];
end

if ~isfield(opt,'nsamples') | opt.nsamples < 1
  opt.nsamples=1;
end
if ~isfield(opt,'repeat') | opt.repeat < 1
  opt.repeat=1;
end
if ~isfield(opt,'display')
  opt.display=1;
end
if ~isfield(opt,'plot')
  opt.plot=1;
end
if ~isfield(opt,'gibbs')
  opt.gibbs=0;
end
if ~isfield(opt,'hmc_opt')
  opt.hmc_opt=hmc2_opt;
  opt.hmc_opt.stepsf='mlp2c_steps';
end
if ~isfield(opt,'persistence_reset')
  opt.persistence_reset=0;
end
if ~isfield(opt,'sample_inputs')
  opt.sample_inputs=0;
end