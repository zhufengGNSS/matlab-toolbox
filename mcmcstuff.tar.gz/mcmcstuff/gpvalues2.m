function [ly, invC] = gpvalues2(gp, tx, ty, invC)
%GPVALUES2 Sample latent values
%
%	Description
%	[LY, INVC] = GPVALUES2(GP, TX, TY, INVC) takes a gp data structure 
%       GP together with a matrix TX of input vectors, matrix TY of target 
%       values and INVC. Samples latent values.
%
%	See also
%	GP2, GP2PAK, GP2UNPAK
%

% Copyright (c) 2000 Aki Vehtari

% This software is distributed under the GNU General Public 
% License (version 2 or later); please refer to the file 
% License.txt, included with the software, for details.

error('No mex-file for this architecture. See Matlab help and convert.m in ./linuxCsource or ./winCsource for help.')
