% FBM Tools Toolbox for Matlab 6.x
% Version 1.0 2003-05-15
% Copyright (C) 1999 Simo S�rkk�
% Copyright (C) 2000-2003 Aki Vehtari
%
% This software is distributed under the GNU General Public 
% Licence (version 2 or later); please refer to the file 
% Licence.txt, included with the software, for details.
%
% Bayesian MLP networks:
%   FBMMLPREAD  - Read MLP networks from FBM log file
%   FBMMLPWRITE - Write network parameter guess into FBM logfile
%   FBMMLPPRED  - Compute predictions of Bayesian MLP
%   FBMMLP2NNET - Convert FBM-generated MLPs into NNET-toolbox 3.x/4.x format
%
% Gaussian processes:
%   FBMGPREAD   - Read GP models from FBM log file
%   FBMGPPRED   - Compute predictions of Gaussian Process
%
% Utilities
%   THIN        - Delete burn-in and thin MCMC-chains
%   JOIN        - Join similar structures of arrays to one structure of arrays
