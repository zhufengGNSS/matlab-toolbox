function y=gminus(x1,x2)
%GMINUS   Generalized minus.
%   C = GMINUS(A,B) subtracts matrix Y from X.
%   The dimensions of the two operands are compared and singleton
%   dimensions in one are copied to match the size of the other.
%   Returns a matrix having dimension lengths equal to
%   MAX(SIZE(A),SIZE(B))
%
% See also GENOPS, GENOP, MINUS.

% Copyright (C) 2003 Aki Vehtari
%
% This software is distributed under the GNU General Public 
% Licence (version 2 or later); please refer to the file 
% Licence.txt, included with the software, for details.

y=genop(@minus,x1,x2);
