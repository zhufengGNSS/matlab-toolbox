FBM tools for Matlab 6.x

Copyright (C) 1999 Simo S�rkk� <ssarkka@lce.hut.fi>
Copyright (C) 2000-2003 Aki Vehtari <Aki.Vehtari@hut.fi>
Maintainer: Aki Vehtari <Aki.Vehtari@hut.fi>

FBM <http://www.cs.toronto.edu/~radford/fbm.software.html> is a
"Software for Flexible Bayesian Modeling and Markov Chain Sampling"
written by Radford Neal <http://www.cs.utoronto.ca/~radford/>.
First goal of the FBM tools was to make convergence diagnostics
easier by reading data from the FBM log files directly to Matlab.
Later simple prediction functions and conversion function for
Mathworks Neural Network toolbox were added. Note, that only some
of the fields from the FBM log files for MLP and GP models are
currently read but changing this is relatively easy.

In 1999 Simo S�rkk� implemented first parts of FBM tools in Matlab
at Helsinki University of Technology, Laboratory of Computational
Engineering <http://www.lce.hut.fi>. Later Aki Vehtari added
additonal utilities, and fixed bugs and documentation.


This software is distributed under the GNU General Public Licence
(version 2 or later); please refer to the file Licence.txt,
included with the software, for details.
